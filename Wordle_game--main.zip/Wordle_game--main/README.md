# Wordle_game



## Instructions to compile wordle_game in C
```bash
gcc wordle.c wordle_functions.c -o wordle
```
words.txt needs to be in the same directory as wordle executable
